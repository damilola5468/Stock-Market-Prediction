from django.contrib import admin
from .models import Main

admin.site.register(Main)
